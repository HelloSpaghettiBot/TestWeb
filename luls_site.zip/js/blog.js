// Blogger integration logic (full enhanced version)
const BLOG_FEED="https://lockedinreviews.blogspot.com/feeds/posts/default?alt=json";
const POSTS_PER_PAGE=6;
let posts=[],filtered=[],page=1;

function strip(html){const d=document.createElement("div");d.innerHTML=html||"";return d.textContent||"";}
function extractImage(e){return e.media$thumbnail?.url?.replace(/\/s\d+/,"/s800")||"";}

function render(container){
  const grid=document.getElementById(container);
  if(!grid)return;
  grid.innerHTML="";
  filtered.slice((page-1)*POSTS_PER_PAGE,page*POSTS_PER_PAGE).forEach(p=>{
    const c=document.createElement("div");
    c.className="card";
    c.innerHTML=`${p.img?`<img src="${p.img}">`:""}<h3>${p.title}</h3><p>${p.snippet}</p><a href="${p.link}" target="_blank" class="btn secondary">Read</a>`;
    grid.appendChild(c);
  });
}

async function load(){
  const r=await fetch(BLOG_FEED);
  const d=await r.json();
  posts=(d.feed.entry||[]).map(e=>({
    title:e.title.$t,
    link:e.link.find(l=>l.rel==="alternate").href,
    snippet:strip(e.summary?.$t||e.content?.$t).slice(0,140)+"…",
    labels:e.category?.map(c=>c.term)||[],
    img:extractImage(e)
  }));
  filtered=[...posts];
  render("blog-preview");
  render("blog-grid");
}
load();